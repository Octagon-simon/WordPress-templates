<?php

require_once( get_template_directory() . '/inc/backend/elementor-widgets/heading.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/button.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/icon-box-1.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/icon-box-2.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/service-box-1.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/service-box-2.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/number-box.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/tech-box.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/image-box.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/portfolio-filter.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/portfolio-carousel.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/post-grid.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/post-carousel.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/team.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/counter.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/counter-2.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/progress-bars.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/pricing-table.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/testimonial-carousel.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/industries-carousel.php' );

require_once( get_template_directory() . '/inc/backend/elementor-widgets/video-button.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/contact-info.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/accordions.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/tabs.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/support-box.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/message-box.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/countdown.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/social-share.php' );
