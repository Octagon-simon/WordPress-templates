<?php
/*
*Template Name: Page Builder Template
*/
get_header();

/*
* get the content of the page 
*/
the_content();

get_footer();
